# City Services App (Flutter + Supabase trial, Django-ready)

Customers and service providers register. An admin approves each profile.
Approved providers publish services, approved customers book them.
Every user gets a unique ID generated from the name they typed (`Ahmed Khan` -> `ahmed-k7m2`).

## What is in this folder

```
supabase/schema.sql          Database, security rules, ID generator, storage (run once)
pubspec.yaml                 Only 3 packages: supabase_flutter, flutter_riverpod, image_picker
lib/
  main.dart                  Starts Supabase and the app
  providers.dart             Riverpod wiring (repositories, current profile, city/category lists)
  core/                      config (keys), theme, shared widgets
  models/models.dart         Profile, ServiceItem, Booking, Option
  data/repositories.dart     ONLY file that talks to Supabase (swap for Django later)
  features/
    auth/                    AuthGate (role + status router), login, register
    shared/                  status screen (waiting/rejected), bookings list, account sheet
    customer/                browse + search, service detail + booking form
    provider/                my services, add service, requests
    admin/                   approve / reject / suspend, view ID documents
```

## Integration steps

### 1. Install the tools
- Flutter SDK (run `flutter doctor` until it is green) and VS Code with the **Flutter** and **Dart** extensions.
- A free account at supabase.com.

### 2. Create the Supabase project
1. New project -> choose a region close to your users -> save the database password.
2. Open **SQL Editor -> New query**, paste all of `supabase/schema.sql`, click **Run**.
   It creates the tables, security rules, the ID generator, the private `documents` bucket and a starter city/category list.
3. Open **Table Editor -> cities** and replace `My City` with your real city. Edit **categories** the same way.
4. **Authentication -> Providers -> Email** must be enabled.
   For the trial, turn **Confirm email** off so you can test quickly. Turn it back on before real users.
5. **Project Settings -> API**: copy the **Project URL** and the **anon public key**.

### 3. Create the Flutter project and drop in this code
```bash
flutter create eservice_app
# copy this folder's lib/ , pubspec.yaml and supabase/ over the new project (replace when asked)
cd eservice_app
flutter pub get
```
Keep the project name `eservice_app` (the code does not import it by name, but pubspec.yaml expects it).

### 4. Platform settings
- **iOS** (`ios/Runner/Info.plist`): add inside `<dict>`:
  ```xml
  <key>NSPhotoLibraryUsageDescription</key>
  <string>Used to upload your ID document.</string>
  ```
- **Android**: nothing extra for picking images from the gallery.

### 5. Run it with your keys
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR-ANON-KEY
```
In VS Code, put the same values in `.vscode/launch.json` so F5 works (do not commit this file):
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "eservice_app",
      "request": "launch",
      "type": "dart",
      "args": [
        "--dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co",
        "--dart-define=SUPABASE_ANON_KEY=YOUR-ANON-KEY"
      ]
    }
  ]
}
```
Set `Config.currency` in `lib/core/config.dart` if you want a currency label on prices.

### 6. Create your admin account
Nobody can sign up as admin from the app. Do it once by hand:
1. Register normally in the app (any role) and note the ID shown on the status screen.
2. In Supabase **SQL Editor** run:
   ```sql
   update profiles set role = 'admin', status = 'approved' where public_id = 'YOUR-ID-HERE';
   ```
3. Sign out and in again. You now see the Admin dashboard.

### 7. Test the full flow
1. Register a **provider** (upload an ID photo on the waiting screen) and a **customer** on two devices or emulators.
2. As admin: open **Pending**, tap **View ID** on the provider, then **Approve** both.
3. Provider: **Add service**. Customer: browse, open it, **Book this service**.
4. Provider: **Requests -> Accept -> Mark completed**. Customer: **Bookings -> Rate this service**.
5. Admin: try **Reject** (reason required) and **Suspend**; confirm the user sees the right screen.

## How the unique ID works
- Created by the database in `generate_public_id()` when the account is created, so it is always unique and nobody can edit it.
- Format: first word of the name (letters a-z, up to 10) + `-` + 4 random characters.
  The characters skip look-alikes (0/o, 1/l/i) so IDs are easy to read out loud.
- The sign-up form shows a live preview of the name part. The random part appears after sign-up.
- Names with no a-z letters (for example Urdu script) become `user-xxxx`. Ask me if you want transliteration.
- The ID is a label, not a secret. Access is protected by the security rules, not by the ID.

## Switching to Django later
1. Rebuild the tables as Django models (same names and columns as `schema.sql`).
2. Rewrite only the method bodies in `lib/data/repositories.dart` to call your REST API. Screens, models and providers stay as they are.
3. Replace Supabase Auth with Django auth + JWT, and the security rules with DRF permissions.
4. Use Django Admin for the approval queue if you want to retire the Flutter admin screens.
5. ID generator in Python (same format):
   ```python
   import re, secrets
   ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"

   def generate_public_id(name: str, exists) -> str:
       first = (name.strip().split() or [""])[0].lower()
       base = re.sub(r"[^a-z]", "", first)[:10] or "user"
       tries = 0
       while True:
           tries += 1
           suffix = "".join(secrets.choice(ALPHABET) for _ in range(4 + tries // 20))
           candidate = f"{base}-{suffix}"
           if not exists(candidate):
               return candidate
   ```

## Not included yet (on purpose, to stay light)
Admin screens for cities and categories (edit them in the Supabase table editor), live updates (pull down to refresh instead), push notifications, chat, online payments, multiple languages.
