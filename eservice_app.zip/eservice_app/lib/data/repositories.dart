import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';

/// ---------------------------------------------------------------------------
/// DATA LAYER: the ONLY file in the app that talks to Supabase.
///
/// Screens call these classes and never call Supabase directly. When you move
/// to Django, rewrite the method bodies here to call your REST API (keep the
/// method names and return types) and no screen has to change.
/// ---------------------------------------------------------------------------

SupabaseClient get _db => Supabase.instance.client;
String get _uid => _db.auth.currentUser!.id;

/// Sign up, sign in, sign out.
class AuthRepository {
  /// Fires whenever the user signs in or out.
  Stream<AuthState> get changes => _db.auth.onAuthStateChange;

  Future<void> signIn(String email, String password) async {
    await _db.auth.signInWithPassword(email: email, password: password);
  }

  /// The extra data is read by the database trigger, which creates the
  /// profile and generates the public ID from [fullName].
  Future<void> signUp({
    required String email,
    required String password,
    required String fullName,
    required String phone,
    required String role, // customer | provider
    required int cityId,
    int? categoryId,
    String? bio,
    int? experienceYears,
  }) async {
    await _db.auth.signUp(
      email: email,
      password: password,
      data: {
        'full_name': fullName,
        'role': role,
        'phone': phone,
        'city_id': cityId.toString(),
        if (categoryId != null) 'category_id': categoryId.toString(),
        if (bio != null && bio.isNotEmpty) 'bio': bio,
        if (experienceYears != null) 'experience_years': experienceYears.toString(),
      },
    );
  }

  Future<void> signOut() => _db.auth.signOut();
}

/// The signed-in user's own profile and documents.
class ProfileRepository {
  Future<Profile?> me() async {
    final user = _db.auth.currentUser;
    if (user == null) return null;
    final row = await _db.from('profiles').select().eq('id', user.id).maybeSingle();
    return row == null ? null : Profile.fromMap(row);
  }

  /// Uploads an ID photo to the private "documents" bucket.
  Future<void> uploadDocument(Uint8List bytes, String ext) async {
    final path = '$_uid/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _db.storage.from('documents').uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: ext == 'png' ? 'image/png' : 'image/jpeg'),
        );
    await _db.from('provider_documents').insert({'provider_id': _uid, 'file_path': path});
  }

  Future<int> documentCount() async {
    final rows = await _db.from('provider_documents').select('id').eq('provider_id', _uid);
    return rows.length;
  }

  /// A rejected user asks for another review.
  Future<void> resubmit() async {
    await _db.rpc('resubmit_profile');
  }
}

/// Cities, categories and service listings.
class CatalogRepository {
  Future<List<Option>> cities() async {
    final rows = await _db.from('cities').select('id,name').eq('is_active', true).order('name');
    return rows.map(Option.fromMap).toList();
  }

  Future<List<Option>> categories() async {
    final rows =
        await _db.from('categories').select('id,name').eq('is_active', true).order('name');
    return rows.map(Option.fromMap).toList();
  }

  /// Published services for customers to browse (best rated first).
  Future<List<ServiceItem>> services({int? cityId, int? categoryId, String? query}) async {
    var q = _db.from('service_feed').select().eq('is_published', true);
    if (cityId != null) q = q.eq('city_id', cityId);
    if (categoryId != null) q = q.eq('category_id', categoryId);
    if (query != null && query.trim().isNotEmpty) q = q.ilike('title', '%${query.trim()}%');
    final rows = await q.order('avg_rating', ascending: false).limit(50);
    return rows.map(ServiceItem.fromMap).toList();
  }

  /// All services of the signed-in provider (published or not).
  Future<List<ServiceItem>> myServices() async {
    final rows = await _db
        .from('service_feed')
        .select()
        .eq('provider_id', _uid)
        .order('title');
    return rows.map(ServiceItem.fromMap).toList();
  }

  Future<void> addService({
    required String title,
    String? description,
    required double price,
    required String priceType,
    required int categoryId,
    required int cityId,
  }) async {
    await _db.from('services').insert({
      'provider_id': _uid,
      'title': title,
      'description': description,
      'price': price,
      'price_type': priceType,
      'category_id': categoryId,
      'city_id': cityId,
    });
  }

  Future<void> setPublished(String serviceId, bool published) async {
    await _db.from('services').update({'is_published': published}).eq('id', serviceId);
  }

  Future<void> deleteService(String serviceId) async {
    await _db.from('services').delete().eq('id', serviceId);
  }
}

/// Bookings and reviews.
class BookingRepository {
  /// The database fills in the provider and service title.
  Future<void> book({
    required String serviceId,
    required DateTime when,
    required String address,
    String? notes,
  }) async {
    await _db.from('bookings').insert({
      'service_id': serviceId,
      'customer_id': _uid,
      'scheduled_at': when.toUtc().toIso8601String(),
      'address': address,
      'notes': notes,
    });
  }

  Future<List<Booking>> mine({required bool asProvider}) async {
    final rows = await _db
        .from('bookings')
        .select('*, reviews(id), '
            'customer:profiles!bookings_customer_id_fkey(full_name,public_id), '
            'provider:profiles!bookings_provider_id_fkey(full_name,public_id)')
        .eq(asProvider ? 'provider_id' : 'customer_id', _uid)
        .order('scheduled_at', ascending: false);
    return rows.map((m) => Booking.fromMap(m, asProvider: asProvider)).toList();
  }

  /// status: accepted | declined | completed | cancelled. The database checks
  /// who is allowed to make each change.
  Future<void> setStatus(String bookingId, String status) async {
    await _db.rpc('set_booking_status', params: {'b': bookingId, 's': status});
  }

  Future<void> review(String bookingId, int rating, String? comment) async {
    await _db.from('reviews').insert({
      'booking_id': bookingId,
      'rating': rating,
      'comment': (comment == null || comment.isEmpty) ? null : comment,
    });
  }
}

/// Admin-only actions.
class AdminRepository {
  Future<List<Profile>> byStatus(String status) async {
    final rows = await _db
        .from('profiles')
        .select()
        .eq('status', status)
        .neq('role', 'admin')
        .order('created_at');
    return rows.map(Profile.fromMap).toList();
  }

  Future<void> review(String profileId, String status, String? reason) async {
    await _db.rpc('review_profile',
        params: {'target': profileId, 'new_status': status, 'reason': reason});
  }

  /// Short-lived (5 min) links to a provider's uploaded ID photos.
  Future<List<String>> documentUrls(String providerId) async {
    final docs =
        await _db.from('provider_documents').select('file_path').eq('provider_id', providerId);
    return Future.wait(docs.map(
        (d) => _db.storage.from('documents').createSignedUrl(d['file_path'] as String, 300)));
  }
}
