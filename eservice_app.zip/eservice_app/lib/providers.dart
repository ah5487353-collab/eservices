import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'data/repositories.dart';
import 'models/models.dart';

// One instance of each repository for the whole app.
final authRepoProvider = Provider<AuthRepository>((_) => AuthRepository());
final profileRepoProvider = Provider<ProfileRepository>((_) => ProfileRepository());
final catalogRepoProvider = Provider<CatalogRepository>((_) => CatalogRepository());
final bookingRepoProvider = Provider<BookingRepository>((_) => BookingRepository());
final adminRepoProvider = Provider<AdminRepository>((_) => AdminRepository());

/// The signed-in user's profile (null when signed out). It reloads by itself
/// whenever the user signs in or out, and the AuthGate reacts to it.
final profileProvider = StreamProvider<Profile?>((ref) async* {
  final auth = ref.watch(authRepoProvider);
  final profiles = ref.watch(profileRepoProvider);
  yield await profiles.me();
  await for (final _ in auth.changes) {
    yield await profiles.me();
  }
});

// Small lists used by dropdowns. Fetched once and cached.
final citiesProvider =
    FutureProvider<List<Option>>((ref) => ref.watch(catalogRepoProvider).cities());
final categoriesProvider =
    FutureProvider<List<Option>>((ref) => ref.watch(catalogRepoProvider).categories());
