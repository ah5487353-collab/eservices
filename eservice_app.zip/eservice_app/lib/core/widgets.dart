import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';
import 'config.dart';

// ----------------------------------------------------------------- helpers

/// Turns any error into one short sentence a user can understand.
String friendlyError(Object e) {
  if (e is AuthException) return e.message;
  if (e is PostgrestException) return e.message;
  if (e is StorageException) return e.message;
  return 'Something went wrong. Check your internet and try again.';
}

void showMessage(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

Future<bool> confirm(BuildContext context, String question, {String yes = 'Yes'}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Text(question),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
      ],
    ),
  );
  return result ?? false;
}

String formatPrice(double price, String priceType) {
  final amount = price == price.roundToDouble() ? price.toStringAsFixed(0) : price.toStringAsFixed(2);
  final label = '${Config.currency} $amount'.trim();
  return priceType == 'hourly' ? '$label / hour' : label;
}

String formatDateTime(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year}  ${two(d.hour)}:${two(d.minute)}';
}

/// Live preview on the sign-up form. Mirrors the first half of the ID the
/// database generates ("Ahmed Khan" -> "ahmed-...."). The random part is
/// added by the database so it is always unique.
String idPreview(String name) {
  final first = name
      .trim()
      .split(RegExp(r'\s+'))
      .first
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z]'), '');
  final base = first.isEmpty ? 'user' : (first.length > 10 ? first.substring(0, 10) : first);
  return '$base-••••';
}

// ----------------------------------------------------------------- widgets

/// Full-width primary button with a built-in loading spinner.
class BigButton extends StatelessWidget {
  const BigButton({super.key, required this.label, required this.onPressed, this.busy = false});

  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        height: 52,
        child: FilledButton(
          onPressed: busy ? null : onPressed,
          child: busy
              ? const SizedBox(
                  width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(label),
        ),
      );
}

/// Small coloured label for a status (pending, approved, completed ...).
class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});

  final String status;

  static const Map<String, Color> _colors = {
    'pending': Colors.orange,
    'requested': Colors.orange,
    'approved': Colors.green,
    'accepted': Colors.green,
    'completed': Colors.teal,
    'rejected': Colors.red,
    'declined': Colors.red,
    'suspended': Colors.red,
    'cancelled': Colors.grey,
  };

  @override
  Widget build(BuildContext context) {
    final color = _colors[status] ?? Colors.blueGrey;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status[0].toUpperCase() + status.substring(1),
        style: TextStyle(color: color.withAlpha(230), fontWeight: FontWeight.w600, fontSize: 12),
      ),
    );
  }
}

/// Shows the user's public ID. Tap to copy.
class IdBadge extends StatelessWidget {
  const IdBadge(this.publicId, {super.key});

  final String publicId;

  @override
  Widget build(BuildContext context) => ActionChip(
        avatar: const Icon(Icons.badge_outlined, size: 18),
        label: Text('ID: $publicId'),
        onPressed: () {
          Clipboard.setData(ClipboardData(text: publicId));
          showMessage(context, 'ID copied');
        },
      );
}

class RatingText extends StatelessWidget {
  const RatingText(this.average, this.count, {super.key});

  final double average;
  final int count;

  @override
  Widget build(BuildContext context) {
    if (count == 0) return Text('New', style: Theme.of(context).textTheme.bodySmall);
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.star_rounded, size: 18, color: Colors.amber.shade700),
      const SizedBox(width: 2),
      Text('${average.toStringAsFixed(1)} ($count)'),
    ]);
  }
}

/// Friendly message for an empty list or an error.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
            if (actionLabel != null) ...[
              const SizedBox(height: 16),
              OutlinedButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ]),
        ),
      );
}

/// A list that loads from a Future, supports pull-to-refresh and handles
/// loading, error and empty states. Used by almost every screen.
class FutureList<T> extends StatelessWidget {
  const FutureList({
    super.key,
    required this.future,
    required this.itemBuilder,
    required this.emptyText,
    required this.onRefresh,
  });

  final Future<List<T>> future;
  final Widget Function(BuildContext context, T item) itemBuilder;
  final String emptyText;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) => FutureBuilder<List<T>>(
        future: future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return EmptyState(
              icon: Icons.wifi_off_rounded,
              message: friendlyError(snap.error!),
              actionLabel: 'Try again',
              onAction: onRefresh,
            );
          }
          final items = snap.data!;
          return RefreshIndicator(
            onRefresh: onRefresh,
            child: items.isEmpty
                ? ListView(children: [
                    const SizedBox(height: 120),
                    EmptyState(icon: Icons.inbox_outlined, message: emptyText),
                  ])
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, i) => itemBuilder(context, items[i]),
                  ),
          );
        },
      );
}

/// Dropdown filled from a city or category list.
class OptionDropdown extends StatelessWidget {
  const OptionDropdown({
    super.key,
    required this.label,
    required this.options,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final AsyncValue<List<Option>> options;
  final int? value;
  final ValueChanged<int?> onChanged;

  @override
  Widget build(BuildContext context) => options.when(
        loading: () => const Padding(
          padding: EdgeInsets.symmetric(vertical: 20),
          child: LinearProgressIndicator(),
        ),
        error: (e, _) => Text(friendlyError(e)),
        data: (items) => DropdownButtonFormField<int>(
          value: value,
          decoration: InputDecoration(labelText: label),
          items: [for (final o in items) DropdownMenuItem(value: o.id, child: Text(o.name))],
          onChanged: onChanged,
          validator: (v) => v == null ? 'Please choose one' : null,
        ),
      );
}
