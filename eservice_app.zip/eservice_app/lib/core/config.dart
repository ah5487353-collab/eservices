/// App-wide settings.
///
/// Supabase keys are passed at run time so they are never committed:
///   flutter run \
///     --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
///     --dart-define=SUPABASE_ANON_KEY=your-anon-key
class Config {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  /// Shown before prices, e.g. 'Rs.' or r'$'. Leave empty to show numbers only.
  static const currency = '';
}
