/// Plain data classes. They only know how to read one row (a Map) coming
/// from the backend. When you move to Django, keep these and change only
/// the map keys if your API names fields differently.

/// A user: customer, provider or admin.
class Profile {
  const Profile({
    required this.id,
    required this.publicId,
    required this.fullName,
    required this.role,
    required this.status,
    this.phone,
    this.rejectionReason,
    this.bio,
    this.cityId,
    this.categoryId,
    this.experienceYears,
  });

  final String id;
  final String publicId; // e.g. "ahmed-k7m2", generated from the name
  final String fullName;
  final String role; // customer | provider | admin
  final String status; // pending | approved | rejected | suspended
  final String? phone;
  final String? rejectionReason;
  final String? bio;
  final int? cityId;
  final int? categoryId;
  final int? experienceYears;

  bool get isApproved => status == 'approved';
  bool get isProvider => role == 'provider';

  factory Profile.fromMap(Map<String, dynamic> m) => Profile(
        id: m['id'] as String,
        publicId: m['public_id'] as String,
        fullName: m['full_name'] as String,
        role: m['role'] as String,
        status: m['status'] as String,
        phone: m['phone'] as String?,
        rejectionReason: m['rejection_reason'] as String?,
        bio: m['bio'] as String?,
        cityId: m['city_id'] as int?,
        categoryId: m['category_id'] as int?,
        experienceYears: m['experience_years'] as int?,
      );
}

/// A city or a category (id + name).
class Option {
  const Option(this.id, this.name);

  final int id;
  final String name;

  factory Option.fromMap(Map<String, dynamic> m) =>
      Option(m['id'] as int, m['name'] as String);
}

/// A service listing together with its provider's name and rating.
class ServiceItem {
  const ServiceItem({
    required this.id,
    required this.title,
    this.description,
    required this.price,
    required this.priceType,
    required this.isPublished,
    required this.categoryId,
    required this.categoryName,
    required this.cityId,
    required this.providerId,
    required this.providerName,
    required this.providerPublicId,
    required this.avgRating,
    required this.reviewCount,
  });

  final String id;
  final String title;
  final String? description;
  final double price;
  final String priceType; // fixed | hourly
  final bool isPublished;
  final int categoryId;
  final String categoryName;
  final int cityId;
  final String providerId;
  final String providerName;
  final String providerPublicId;
  final double avgRating;
  final int reviewCount;

  factory ServiceItem.fromMap(Map<String, dynamic> m) => ServiceItem(
        id: m['id'] as String,
        title: m['title'] as String,
        description: m['description'] as String?,
        price: (m['price'] as num).toDouble(),
        priceType: m['price_type'] as String,
        isPublished: m['is_published'] as bool,
        categoryId: m['category_id'] as int,
        categoryName: m['category_name'] as String,
        cityId: m['city_id'] as int,
        providerId: m['provider_id'] as String,
        providerName: m['provider_name'] as String,
        providerPublicId: m['provider_public_id'] as String,
        avgRating: (m['avg_rating'] as num).toDouble(),
        reviewCount: (m['review_count'] as num).toInt(),
      );
}

/// A booking, seen from one side. [otherName] is the provider's name for a
/// customer, and the customer's name for a provider.
class Booking {
  const Booking({
    required this.id,
    required this.serviceTitle,
    required this.status,
    required this.scheduledAt,
    required this.address,
    this.notes,
    required this.otherName,
    required this.otherPublicId,
    required this.reviewed,
  });

  final String id;
  final String serviceTitle;
  final String status; // requested | accepted | declined | completed | cancelled
  final DateTime scheduledAt;
  final String address;
  final String? notes;
  final String otherName;
  final String otherPublicId;
  final bool reviewed;

  factory Booking.fromMap(Map<String, dynamic> m, {required bool asProvider}) {
    final other = (m[asProvider ? 'customer' : 'provider'] as Map<String, dynamic>?) ??
        <String, dynamic>{};
    final review = m['reviews']; // a list or a single object, depending on the API version
    return Booking(
      id: m['id'] as String,
      serviceTitle: m['service_title'] as String,
      status: m['status'] as String,
      scheduledAt: DateTime.parse(m['scheduled_at'] as String).toLocal(),
      address: m['address'] as String,
      notes: m['notes'] as String?,
      otherName: (other['full_name'] as String?) ?? 'Unknown',
      otherPublicId: (other['public_id'] as String?) ?? '',
      reviewed: review is List ? review.isNotEmpty : review != null,
    );
  }
}
