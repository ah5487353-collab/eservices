import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../providers.dart';

/// One sign-up form for both roles. Providers see three extra fields.
/// The unique ID is created by the database from the name typed here.
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _bio = TextEditingController();
  final _years = TextEditingController();
  String _role = 'customer';
  int? _cityId;
  int? _categoryId;
  bool _busy = false;

  bool get _isProvider => _role == 'provider';

  @override
  void dispose() {
    for (final c in [_name, _phone, _email, _password, _bio, _years]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _busy = true);
    try {
      await ref.read(authRepoProvider).signUp(
            email: _email.text.trim(),
            password: _password.text,
            fullName: _name.text.trim(),
            phone: _phone.text.trim(),
            role: _role,
            cityId: _cityId!,
            categoryId: _isProvider ? _categoryId : null,
            bio: _isProvider ? _bio.text.trim() : null,
            experienceYears: _isProvider ? int.tryParse(_years.text.trim()) : null,
          );
      // Back to the root. If the user is already signed in, the AuthGate shows
      // the "waiting for approval" screen; otherwise they land on Login.
      nav.popUntil((r) => r.isFirst);
      messenger.showSnackBar(const SnackBar(
        content: Text('Account created. Confirm your email if asked, then sign in. '
            'An admin will review your profile.'),
      ));
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: SafeArea(
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                      value: 'customer', icon: Icon(Icons.person_outline), label: Text('Customer')),
                  ButtonSegment(
                      value: 'provider',
                      icon: Icon(Icons.handyman_outlined),
                      label: Text('Provider')),
                ],
                selected: {_role},
                onSelectionChanged: (s) => setState(() => _role = s.first),
              ),
              const SizedBox(height: 8),
              Text(_isProvider ? 'I offer services' : 'I am looking for services',
                  style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 20),
              TextFormField(
                controller: _name,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(
                  labelText: 'Full name',
                  helperText: 'Your unique ID will look like ${idPreview(_name.text)}',
                ),
                onChanged: (_) => setState(() {}),
                validator: (v) =>
                    (v == null || v.trim().length < 2) ? 'Enter your name' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone number'),
                validator: (v) =>
                    (v == null || v.trim().length < 7) ? 'Enter a valid phone number' : null,
              ),
              const SizedBox(height: 14),
              OptionDropdown(
                label: 'City',
                options: ref.watch(citiesProvider),
                value: _cityId,
                onChanged: (v) => setState(() => _cityId = v),
              ),
              if (_isProvider) ...[
                const SizedBox(height: 14),
                OptionDropdown(
                  label: 'Your main service',
                  options: ref.watch(categoriesProvider),
                  value: _categoryId,
                  onChanged: (v) => setState(() => _categoryId = v),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _years,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Years of experience'),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _bio,
                  maxLines: 3,
                  maxLength: 300,
                  decoration: const InputDecoration(
                      labelText: 'About you', hintText: 'What you do and where you work'),
                ),
              ],
              const SizedBox(height: 14),
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(
                    labelText: 'Password', helperText: 'At least 8 characters'),
                validator: (v) =>
                    (v == null || v.length < 8) ? 'Use at least 8 characters' : null,
              ),
              const SizedBox(height: 24),
              BigButton(label: 'Create account', busy: _busy, onPressed: _submit),
            ],
          ),
        ),
      ),
    );
  }
}
