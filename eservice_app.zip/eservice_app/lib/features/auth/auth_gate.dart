import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../providers.dart';
import '../admin/admin_home.dart';
import '../customer/customer_home.dart';
import '../provider/provider_home.dart';
import '../shared/status_screen.dart';
import 'login_screen.dart';

/// Decides which screen to show, from the user's role and approval status:
///
///   signed out                 -> Login
///   not approved yet           -> Status (waiting / rejected / suspended)
///   approved admin             -> Admin dashboard
///   approved provider          -> Provider home
///   approved customer          -> Customer home
class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    return profile.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(
        body: EmptyState(
          icon: Icons.wifi_off_rounded,
          message: friendlyError(e),
          actionLabel: 'Try again',
          onAction: () => ref.invalidate(profileProvider),
        ),
      ),
      data: (p) {
        if (p == null) return const LoginScreen();
        if (!p.isApproved) return StatusScreen(profile: p);
        if (p.role == 'admin') return const AdminHome();
        if (p.isProvider) return const ProviderHome();
        return const CustomerHome();
      },
    );
  }
}
