import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';
import '../shared/account_sheet.dart';
import '../shared/bookings_tab.dart';
import 'service_detail.dart';

/// Customer app: Browse + My bookings.
class CustomerHome extends ConsumerStatefulWidget {
  const CustomerHome({super.key});

  @override
  ConsumerState<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends ConsumerState<CustomerHome> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(profileProvider).valueOrNull;
    return Scaffold(
      appBar: AppBar(
        title: Text(_tab == 0 ? 'Find a service' : 'My bookings'),
        actions: [
          IconButton(
            tooltip: 'Account',
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: me == null ? null : () => showAccountSheet(context, ref, me),
          ),
        ],
      ),
      // Only the visible tab is built, so each visit shows fresh data.
      body: _tab == 0
          ? BrowseTab(key: const ValueKey('browse'), cityId: me?.cityId)
          : const BookingsTab(key: ValueKey('bookings'), asProvider: false),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.search), label: 'Browse'),
          NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Bookings'),
        ],
      ),
    );
  }
}

/// Search box + category chips + list of services in the user's city.
class BrowseTab extends ConsumerStatefulWidget {
  const BrowseTab({super.key, required this.cityId});

  final int? cityId;

  @override
  ConsumerState<BrowseTab> createState() => _BrowseTabState();
}

class _BrowseTabState extends ConsumerState<BrowseTab> {
  final _search = TextEditingController();
  int? _categoryId;
  late Future<List<ServiceItem>> _future = _load();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<List<ServiceItem>> _load() => ref
      .read(catalogRepoProvider)
      .services(cityId: widget.cityId, categoryId: _categoryId, query: _search.text);

  void _reload() => setState(() => _future = _load());

  Future<void> _refresh() async {
    _reload();
    await _future.catchError((_) => <ServiceItem>[]);
  }

  Widget _chip(String label, int? id) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _categoryId == id,
          onSelected: (_) {
            _categoryId = id;
            _reload();
          },
        ),
      );

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider);
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: TextField(
          controller: _search,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: 'Search services',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: _search.text.isEmpty
                ? null
                : IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _search.clear();
                      _reload();
                    },
                  ),
          ),
          onChanged: (_) => setState(() {}),
          onSubmitted: (_) => _reload(),
        ),
      ),
      SizedBox(
        height: 52,
        child: categories.maybeWhen(
          data: (cats) => ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            children: [_chip('All', null), for (final c in cats) _chip(c.name, c.id)],
          ),
          orElse: () => const SizedBox.shrink(),
        ),
      ),
      Expanded(
        child: FutureList<ServiceItem>(
          future: _future,
          onRefresh: _refresh,
          emptyText: 'No services found. Try another category or search.',
          itemBuilder: (context, s) => _ServiceCard(service: s),
        ),
      ),
    ]);
  }
}

class _ServiceCard extends StatelessWidget {
  const _ServiceCard({required this.service});

  final ServiceItem service;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => ServiceDetailScreen(service: service))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(service.title,
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
              ),
              Text(formatPrice(service.price, service.priceType),
                  style: theme.textTheme.titleSmall?.copyWith(
                      color: theme.colorScheme.primary, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 4),
            Text(service.categoryName, style: theme.textTheme.bodySmall),
            const SizedBox(height: 10),
            Row(children: [
              const Icon(Icons.person_outline, size: 18),
              const SizedBox(width: 4),
              Expanded(child: Text(service.providerName, overflow: TextOverflow.ellipsis)),
              RatingText(service.avgRating, service.reviewCount),
            ]),
          ]),
        ),
      ),
    );
  }
}
