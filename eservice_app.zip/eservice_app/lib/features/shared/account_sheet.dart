import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';

/// Bottom sheet with the user's name, public ID and sign-out.
void showAccountSheet(BuildContext context, WidgetRef ref, Profile p) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(p.fullName, style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(switch (p.role) {
              'provider' => 'Service provider',
              'admin' => 'Admin',
              _ => 'Customer',
            }),
            const SizedBox(height: 12),
            IdBadge(p.publicId),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: () {
                Navigator.pop(ctx);
                ref.read(authRepoProvider).signOut();
              },
              icon: const Icon(Icons.logout),
              label: const Text('Sign out'),
            ),
          ],
        ),
      ),
    ),
  );
}
