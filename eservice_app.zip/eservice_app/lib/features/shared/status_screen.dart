import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';

/// Shown to anyone who is not approved yet: waiting, rejected or suspended.
/// Providers can also upload their ID document here.
class StatusScreen extends ConsumerStatefulWidget {
  const StatusScreen({super.key, required this.profile});

  final Profile profile;

  @override
  ConsumerState<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends ConsumerState<StatusScreen> {
  bool _busy = false;
  int _docs = 0;

  @override
  void initState() {
    super.initState();
    _loadDocs();
  }

  Future<void> _loadDocs() async {
    if (!widget.profile.isProvider) return;
    try {
      final n = await ref.read(profileRepoProvider).documentCount();
      if (mounted) setState(() => _docs = n);
    } catch (_) {
      // Not critical: the count simply stays at 0.
    }
  }

  Future<void> _upload() async {
    try {
      // Resized and compressed on the phone so uploads stay small.
      final file = await ImagePicker()
          .pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 80);
      if (file == null) return;
      setState(() => _busy = true);
      final bytes = await file.readAsBytes();
      final ext = file.name.split('.').last.toLowerCase();
      await ref.read(profileRepoProvider).uploadDocument(bytes, ext);
      await _loadDocs();
      if (mounted) showMessage(context, 'Document uploaded');
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resubmit() async {
    setState(() => _busy = true);
    try {
      await ref.read(profileRepoProvider).resubmit();
      ref.invalidate(profileProvider);
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;
    final theme = Theme.of(context);
    final info = switch (p.status) {
      'rejected' => (
          Icons.cancel_outlined,
          'Profile not approved',
          'Fix the issue below, then send your profile for review again.'
        ),
      'suspended' => (
          Icons.pause_circle_outline,
          'Account suspended',
          'Contact support if you think this is a mistake.'
        ),
      _ => (
          Icons.hourglass_top_rounded,
          'Waiting for approval',
          'An admin is reviewing your profile. You get access as soon as it is approved.'
        ),
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your account'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            icon: const Icon(Icons.logout),
            onPressed: () => ref.read(authRepoProvider).signOut(),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Icon(info.$1, size: 72, color: theme.colorScheme.primary),
          const SizedBox(height: 16),
          Text(info.$2,
              textAlign: TextAlign.center,
              style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(info.$3, textAlign: TextAlign.center, style: theme.textTheme.bodyLarge),
          const SizedBox(height: 16),
          Center(child: IdBadge(p.publicId)),
          const SizedBox(height: 4),
          Text('Keep this ID. Support may ask for it.',
              textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
          if (p.rejectionReason != null && p.rejectionReason!.isNotEmpty) ...[
            const SizedBox(height: 20),
            Card(
              color: theme.colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Reason: ${p.rejectionReason}'),
              ),
            ),
          ],
          if (p.isProvider) ...[
            const SizedBox(height: 24),
            Text('ID document', style: theme.textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              _docs == 0
                  ? 'Upload a clear photo of your ID or work certificate. It helps the admin approve you faster.'
                  : '$_docs uploaded. You can add another if needed.',
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _busy ? null : _upload,
              icon: const Icon(Icons.upload_file),
              label: const Text('Add ID photo'),
            ),
          ],
          const SizedBox(height: 24),
          if (p.status == 'rejected')
            BigButton(label: 'Send for review again', busy: _busy, onPressed: _resubmit)
          else
            BigButton(
              label: 'Check status',
              onPressed: () => ref.invalidate(profileProvider),
            ),
        ],
      ),
    );
  }
}
