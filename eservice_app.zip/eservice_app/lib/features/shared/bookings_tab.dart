import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';

/// Booking list used by both sides.
///   customer: can cancel, and rate a completed booking
///   provider: can accept / decline requests and mark jobs completed
class BookingsTab extends ConsumerStatefulWidget {
  const BookingsTab({super.key, required this.asProvider});

  final bool asProvider;

  @override
  ConsumerState<BookingsTab> createState() => _BookingsTabState();
}

class _BookingsTabState extends ConsumerState<BookingsTab> {
  late Future<List<Booking>> _future = _load();

  Future<List<Booking>> _load() =>
      ref.read(bookingRepoProvider).mine(asProvider: widget.asProvider);

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future.catchError((_) => <Booking>[]);
  }

  Future<void> _change(Booking b, String status, {String? ask}) async {
    if (ask != null && !await confirm(context, ask)) return;
    try {
      await ref.read(bookingRepoProvider).setStatus(b.id, status);
      await _refresh();
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  Future<void> _rate(Booking b) async {
    var stars = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Rate this service'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 1; i <= 5; i++)
                IconButton(
                  onPressed: () => setLocal(() => stars = i),
                  icon: Icon(i <= stars ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: Colors.amber.shade700, size: 32),
                ),
            ]),
            TextField(
              controller: comment,
              maxLines: 2,
              decoration: const InputDecoration(hintText: 'Add a comment (optional)'),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Not now')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Submit')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(bookingRepoProvider).review(b.id, stars, comment.text.trim());
      await _refresh();
      if (mounted) showMessage(context, 'Thanks for your review');
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  List<Widget> _actions(Booking b) {
    if (widget.asProvider) {
      if (b.status == 'requested') {
        return [
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => _change(b, 'declined', ask: 'Decline this request?'),
                child: const Text('Decline'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton(
                onPressed: () => _change(b, 'accepted'),
                child: const Text('Accept'),
              ),
            ),
          ]),
        ];
      }
      if (b.status == 'accepted') {
        return [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => _change(b, 'completed', ask: 'Mark this job as completed?'),
              child: const Text('Mark completed'),
            ),
          ),
        ];
      }
      return [];
    }
    if (b.status == 'requested' || b.status == 'accepted') {
      return [
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: () => _change(b, 'cancelled', ask: 'Cancel this booking?'),
            child: const Text('Cancel booking'),
          ),
        ),
      ];
    }
    if (b.status == 'completed' && !b.reviewed) {
      return [
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _rate(b),
            icon: const Icon(Icons.star_outline_rounded),
            label: const Text('Rate this service'),
          ),
        ),
      ];
    }
    return [];
  }

  Widget _line(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ]),
      );

  @override
  Widget build(BuildContext context) => FutureList<Booking>(
        future: _future,
        onRefresh: _refresh,
        emptyText: widget.asProvider
            ? 'No requests yet. Customers will appear here when they book you.'
            : 'No bookings yet. Find a service and book it.',
        itemBuilder: (context, b) {
          final actions = _actions(b);
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text(b.serviceTitle,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600)),
                  ),
                  StatusChip(b.status),
                ]),
                const SizedBox(height: 8),
                _line(Icons.person_outline,
                    b.otherPublicId.isEmpty ? b.otherName : '${b.otherName}  (${b.otherPublicId})'),
                _line(Icons.schedule, formatDateTime(b.scheduledAt)),
                _line(Icons.place_outlined, b.address),
                if (b.notes != null && b.notes!.isNotEmpty) _line(Icons.notes, b.notes!),
                if (actions.isNotEmpty) ...[const SizedBox(height: 12), ...actions],
              ]),
            ),
          );
        },
      );
}
