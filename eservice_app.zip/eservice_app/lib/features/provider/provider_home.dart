import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';
import '../shared/account_sheet.dart';
import '../shared/bookings_tab.dart';
import 'add_service_screen.dart';

/// Provider app: My services + Requests.
class ProviderHome extends ConsumerStatefulWidget {
  const ProviderHome({super.key});

  @override
  ConsumerState<ProviderHome> createState() => _ProviderHomeState();
}

class _ProviderHomeState extends ConsumerState<ProviderHome> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(profileProvider).valueOrNull;
    return Scaffold(
      appBar: AppBar(
        title: Text(_tab == 0 ? 'My services' : 'Requests'),
        actions: [
          IconButton(
            tooltip: 'Account',
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: me == null ? null : () => showAccountSheet(context, ref, me),
          ),
        ],
      ),
      body: _tab == 0
          ? MyServicesTab(key: const ValueKey('services'), profile: me)
          : const BookingsTab(key: ValueKey('requests'), asProvider: true),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.handyman_outlined), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.inbox_outlined), label: 'Requests'),
        ],
      ),
    );
  }
}

class MyServicesTab extends ConsumerStatefulWidget {
  const MyServicesTab({super.key, required this.profile});

  final Profile? profile;

  @override
  ConsumerState<MyServicesTab> createState() => _MyServicesTabState();
}

class _MyServicesTabState extends ConsumerState<MyServicesTab> {
  late Future<List<ServiceItem>> _future = _load();

  Future<List<ServiceItem>> _load() => ref.read(catalogRepoProvider).myServices();

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future.catchError((_) => <ServiceItem>[]);
  }

  Future<void> _add() async {
    final added = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => AddServiceScreen(profile: widget.profile)),
    );
    if (added == true) await _refresh();
  }

  Future<void> _toggle(ServiceItem s, bool value) async {
    try {
      await ref.read(catalogRepoProvider).setPublished(s.id, value);
      await _refresh();
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  Future<void> _delete(ServiceItem s) async {
    if (!await confirm(context, 'Delete "${s.title}"?', yes: 'Delete')) return;
    try {
      await ref.read(catalogRepoProvider).deleteService(s.id);
      await _refresh();
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _add,
          icon: const Icon(Icons.add),
          label: const Text('Add service'),
        ),
        body: FutureList<ServiceItem>(
          future: _future,
          onRefresh: _refresh,
          emptyText: 'You have no services yet. Tap "Add service" to publish your first one.',
          itemBuilder: (context, s) => Card(
            child: ListTile(
              contentPadding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
              title: Text(s.title),
              subtitle: Text(
                  '${s.categoryName}  •  ${formatPrice(s.price, s.priceType)}\n'
                  '${s.isPublished ? 'Visible to customers' : 'Hidden'}'),
              isThreeLine: true,
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                Switch(value: s.isPublished, onChanged: (v) => _toggle(s, v)),
                IconButton(
                  tooltip: 'Delete',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _delete(s),
                ),
              ]),
            ),
          ),
        ),
      );
}
