import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';

/// Form to publish a new service. Pops with `true` when saved.
class AddServiceScreen extends ConsumerStatefulWidget {
  const AddServiceScreen({super.key, required this.profile});

  final Profile? profile;

  @override
  ConsumerState<AddServiceScreen> createState() => _AddServiceScreenState();
}

class _AddServiceScreenState extends ConsumerState<AddServiceScreen> {
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _price = TextEditingController();
  String _priceType = 'fixed';
  late int? _categoryId = widget.profile?.categoryId; // default to the provider's main service
  late int? _cityId = widget.profile?.cityId; // default to the provider's city
  bool _busy = false;

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _price.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      await ref.read(catalogRepoProvider).addService(
            title: _title.text.trim(),
            description: _description.text.trim().isEmpty ? null : _description.text.trim(),
            price: double.parse(_price.text.trim()),
            priceType: _priceType,
            categoryId: _categoryId!,
            cityId: _cityId!,
          );
      nav.pop(true);
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Add a service')),
        body: SafeArea(
          child: Form(
            key: _form,
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                TextFormField(
                  controller: _title,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                      labelText: 'Service title', hintText: 'e.g. Kitchen tap repair'),
                  validator: (v) =>
                      (v == null || v.trim().length < 3) ? 'Enter a short title' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _description,
                  maxLines: 4,
                  maxLength: 500,
                  decoration: const InputDecoration(labelText: 'Description (optional)'),
                ),
                const SizedBox(height: 6),
                OptionDropdown(
                  label: 'Category',
                  options: ref.watch(categoriesProvider),
                  value: _categoryId,
                  onChanged: (v) => setState(() => _categoryId = v),
                ),
                const SizedBox(height: 14),
                OptionDropdown(
                  label: 'City',
                  options: ref.watch(citiesProvider),
                  value: _cityId,
                  onChanged: (v) => setState(() => _cityId = v),
                ),
                const SizedBox(height: 14),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'fixed', label: Text('Fixed price')),
                    ButtonSegment(value: 'hourly', label: Text('Per hour')),
                  ],
                  selected: {_priceType},
                  onSelectionChanged: (s) => setState(() => _priceType = s.first),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _price,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Price'),
                  validator: (v) {
                    final n = double.tryParse((v ?? '').trim());
                    return (n == null || n < 0) ? 'Enter a valid price' : null;
                  },
                ),
                const SizedBox(height: 24),
                BigButton(label: 'Publish service', busy: _busy, onPressed: _save),
              ],
            ),
          ),
        ),
      );
}
