import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets.dart';
import '../../models/models.dart';
import '../../providers.dart';
import '../shared/account_sheet.dart';

/// Admin dashboard: one tab per profile status. Approve, reject or suspend
/// customers and providers, and look at provider ID documents.
class AdminHome extends ConsumerStatefulWidget {
  const AdminHome({super.key});

  @override
  ConsumerState<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends ConsumerState<AdminHome> {
  static const _tabs = [
    ('pending', 'Pending'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected'),
    ('suspended', 'Suspended'),
  ];

  // Bumped after every decision so all four tabs reload.
  int _tick = 0;

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(profileProvider).valueOrNull;
    return DefaultTabController(
      length: _tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Admin'),
          actions: [
            IconButton(
              tooltip: 'Account',
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: me == null ? null : () => showAccountSheet(context, ref, me),
            ),
          ],
          bottom: TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [for (final t in _tabs) Tab(text: t.$2)],
          ),
        ),
        body: TabBarView(children: [
          for (final t in _tabs)
            ProfileList(
              key: ValueKey(t.$1),
              status: t.$1,
              tick: _tick,
              onChanged: () => setState(() => _tick++),
            ),
        ]),
      ),
    );
  }
}

class ProfileList extends ConsumerStatefulWidget {
  const ProfileList({
    super.key,
    required this.status,
    required this.tick,
    required this.onChanged,
  });

  final String status;
  final int tick;
  final VoidCallback onChanged;

  @override
  ConsumerState<ProfileList> createState() => _ProfileListState();
}

class _ProfileListState extends ConsumerState<ProfileList> {
  late Future<List<Profile>> _future = _load();

  Future<List<Profile>> _load() => ref.read(adminRepoProvider).byStatus(widget.status);

  @override
  void didUpdateWidget(ProfileList old) {
    super.didUpdateWidget(old);
    if (old.tick != widget.tick) _future = _load();
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future.catchError((_) => <Profile>[]);
  }

  Future<String?> _askReason(String title) async {
    final controller = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          maxLines: 3,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'The user will see this reason'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final text = controller.text.trim();
              if (text.isNotEmpty) Navigator.pop(ctx, text);
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
    return reason;
  }

  Future<void> _decide(Profile p, String status) async {
    String? reason;
    if (status == 'rejected' || status == 'suspended') {
      reason = await _askReason(
          status == 'rejected' ? 'Why is this profile rejected?' : 'Why is this account suspended?');
      if (reason == null) return; // cancelled
    }
    try {
      await ref.read(adminRepoProvider).review(p.id, status, reason);
      widget.onChanged();
      if (mounted) showMessage(context, '${p.fullName}: $status');
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  Future<void> _viewDocuments(Profile p) async {
    try {
      final urls = await ref.read(adminRepoProvider).documentUrls(p.id);
      if (!mounted) return;
      if (urls.isEmpty) {
        showMessage(context, 'No document uploaded yet');
        return;
      }
      await showDialog<void>(
        context: context,
        builder: (ctx) => Dialog(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.all(16),
            children: [
              for (final u in urls)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Image.network(
                    u,
                    loadingBuilder: (c, child, progress) => progress == null
                        ? child
                        : const SizedBox(height: 120, child: Center(child: CircularProgressIndicator())),
                    errorBuilder: (c, e, s) => const Text('Could not load this document'),
                  ),
                ),
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
            ],
          ),
        ),
      );
    } catch (e) {
      if (mounted) showMessage(context, friendlyError(e));
    }
  }

  List<Widget> _buttons(Profile p) {
    final docs = OutlinedButton(
        onPressed: () => _viewDocuments(p), child: const Text('View ID'));
    switch (p.status) {
      case 'pending':
        return [
          if (p.isProvider) docs,
          OutlinedButton(onPressed: () => _decide(p, 'rejected'), child: const Text('Reject')),
          FilledButton(onPressed: () => _decide(p, 'approved'), child: const Text('Approve')),
        ];
      case 'approved':
        return [
          if (p.isProvider) docs,
          OutlinedButton(onPressed: () => _decide(p, 'suspended'), child: const Text('Suspend')),
        ];
      default: // rejected or suspended
        return [
          if (p.isProvider) docs,
          FilledButton(onPressed: () => _decide(p, 'approved'), child: const Text('Approve')),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureList<Profile>(
      future: _future,
      onRefresh: _refresh,
      emptyText: 'Nobody here right now.',
      itemBuilder: (context, p) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(p.fullName,
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
              ),
              Text(p.isProvider ? 'Provider' : 'Customer', style: theme.textTheme.bodySmall),
            ]),
            const SizedBox(height: 8),
            IdBadge(p.publicId),
            if (p.phone != null) Text('Phone: ${p.phone}'),
            if (p.isProvider && p.experienceYears != null)
              Text('Experience: ${p.experienceYears} years'),
            if (p.bio != null && p.bio!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(p.bio!),
            ],
            if (p.rejectionReason != null && p.rejectionReason!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Reason: ${p.rejectionReason}',
                  style: TextStyle(color: theme.colorScheme.error)),
            ],
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: _buttons(p)),
          ]),
        ),
      ),
    );
  }
}
