-- =====================================================================
-- City E-Services — Supabase schema
-- Run this whole file ONCE on a fresh project:
--   Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Written as plain Postgres so it maps 1:1 to Django models later.
-- =====================================================================

-- ---------- 1. Tables ------------------------------------------------

create table cities (
  id        serial primary key,
  name      text not null unique,
  is_active boolean not null default true
);

create table categories (
  id        serial primary key,
  name      text not null unique,
  is_active boolean not null default true
);

-- One row per user (customer, provider or admin). Created automatically
-- by the sign-up trigger in section 3.
create table profiles (
  id               uuid primary key references auth.users(id) on delete cascade,
  public_id        text not null unique,          -- e.g. "ahmed-k7m2" (generated from the name)
  full_name        text not null,
  phone            text,
  role             text not null check (role in ('customer','provider','admin')),
  status           text not null default 'pending'
                   check (status in ('pending','approved','rejected','suspended')),
  rejection_reason text,
  city_id          int references cities(id),
  -- provider-only fields (null for customers)
  category_id      int references categories(id),
  bio              text,
  experience_years int,
  reviewed_by      uuid references profiles(id),
  reviewed_at      timestamptz,
  created_at       timestamptz not null default now()
);
create index profiles_status_idx on profiles (status, role);

create table provider_documents (
  id          uuid primary key default gen_random_uuid(),
  provider_id uuid not null references profiles(id) on delete cascade,
  file_path   text not null,                      -- path inside the private "documents" bucket
  created_at  timestamptz not null default now()
);

create table services (
  id           uuid primary key default gen_random_uuid(),
  provider_id  uuid not null references profiles(id) on delete cascade,
  category_id  int  not null references categories(id),
  city_id      int  not null references cities(id),
  title        text not null,
  description  text,
  price        numeric(10,2) not null check (price >= 0),
  price_type   text not null default 'fixed' check (price_type in ('fixed','hourly')),
  is_published boolean not null default true,
  created_at   timestamptz not null default now()
);
create index services_browse_idx on services (city_id, category_id) where is_published;

create table bookings (
  id            uuid primary key default gen_random_uuid(),
  service_id    uuid references services(id) on delete set null,
  service_title text not null,                    -- copied at booking time (history survives edits)
  customer_id   uuid not null references profiles(id),
  provider_id   uuid not null references profiles(id),
  scheduled_at  timestamptz not null,
  address       text not null,
  notes         text,
  status        text not null default 'requested'
                check (status in ('requested','accepted','declined','completed','cancelled')),
  created_at    timestamptz not null default now()
);
create index bookings_customer_idx on bookings (customer_id, status);
create index bookings_provider_idx on bookings (provider_id, status);

create table reviews (
  id          uuid primary key default gen_random_uuid(),
  booking_id  uuid not null unique references bookings(id) on delete cascade,
  customer_id uuid not null references profiles(id),
  provider_id uuid not null references profiles(id),
  rating      int not null check (rating between 1 and 5),
  comment     text,
  created_at  timestamptz not null default now()
);

-- ---------- 2. Helper functions --------------------------------------

-- Random, readable ID built from the name the user typed:
--   "Ahmed Khan"  ->  ahmed-k7m2
-- First word of the name (a-z only, max 10 chars) + 4 random characters.
-- The alphabet skips look-alike characters (0/o, 1/l/i). If a collision
-- keeps happening the suffix grows, so it can never loop forever.
-- Names with no a-z letters (e.g. Urdu script) fall back to "user-xxxx".
create or replace function generate_public_id(p_name text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  alphabet  constant text := 'abcdefghjkmnpqrstuvwxyz23456789';
  base      text;
  suffix    text;
  candidate text;
  tries     int := 0;
  len       int;
  i         int;
begin
  base := left(
    regexp_replace(lower(split_part(trim(coalesce(p_name, '')), ' ', 1)), '[^a-z]', '', 'g'),
    10);
  if base = '' then base := 'user'; end if;

  loop
    tries := tries + 1;
    len := 4 + (tries / 20);
    suffix := '';
    for i in 1..len loop
      suffix := suffix || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    candidate := base || '-' || suffix;
    exit when not exists (select 1 from profiles where public_id = candidate);
  end loop;

  return candidate;
end;
$$;

-- Role checks used by the security policies below.
create or replace function is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles
                 where id = auth.uid() and role = 'admin' and status = 'approved');
$$;

create or replace function is_approved() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'approved');
$$;

create or replace function is_approved_provider() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles
                 where id = auth.uid() and role = 'provider' and status = 'approved');
$$;

create or replace function is_approved_customer() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles
                 where id = auth.uid() and role = 'customer' and status = 'approved');
$$;

create or replace function provider_is_approved(pid uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles
                 where id = pid and role = 'provider' and status = 'approved');
$$;

-- ---------- 3. Sign-up trigger ---------------------------------------
-- The app sends full_name / role / city etc. as sign-up metadata. This
-- trigger turns that into a profile row and generates the public ID.
-- Nobody can register as admin from the app (see the role check).
create or replace function handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role text := coalesce(new.raw_user_meta_data->>'role', 'customer');
  v_name text := coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'), ''), 'User');
begin
  if v_role not in ('customer','provider') then v_role := 'customer'; end if;

  insert into profiles (id, public_id, full_name, phone, role, status,
                        city_id, category_id, bio, experience_years)
  values (
    new.id,
    generate_public_id(v_name),
    v_name,
    nullif(new.raw_user_meta_data->>'phone', ''),
    v_role,
    'pending',   -- both roles wait for admin approval.
                 -- To auto-approve customers use:
                 -- case when v_role = 'customer' then 'approved' else 'pending' end
    nullif(new.raw_user_meta_data->>'city_id', '')::int,
    nullif(new.raw_user_meta_data->>'category_id', '')::int,
    nullif(new.raw_user_meta_data->>'bio', ''),
    nullif(new.raw_user_meta_data->>'experience_years', '')::int
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- Booking: fill provider + title from the service, and refuse unavailable ones.
create or replace function set_booking_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare s services;
begin
  select * into s from services where id = new.service_id and is_published;
  if not found or not provider_is_approved(s.provider_id) then
    raise exception 'This service is not available';
  end if;
  new.provider_id   := s.provider_id;
  new.service_title := s.title;
  return new;
end;
$$;
create trigger bookings_defaults before insert on bookings
  for each row execute function set_booking_defaults();

-- Review: only for your own completed booking; fill customer + provider.
create or replace function set_review_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare bk bookings;
begin
  select * into bk from bookings where id = new.booking_id;
  if not found or bk.customer_id <> auth.uid() or bk.status <> 'completed' then
    raise exception 'You can only review your own completed bookings';
  end if;
  new.customer_id := bk.customer_id;
  new.provider_id := bk.provider_id;
  return new;
end;
$$;
create trigger reviews_defaults before insert on reviews
  for each row execute function set_review_defaults();

-- ---------- 4. Actions exposed to the app (RPC) ------------------------

-- Admin approves / rejects / suspends a profile.
create or replace function review_profile(target uuid, new_status text, reason text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if new_status not in ('approved','rejected','suspended') then
    raise exception 'Invalid status';
  end if;
  update profiles
     set status = new_status,
         rejection_reason = case when new_status = 'approved' then null else reason end,
         reviewed_by = auth.uid(),
         reviewed_at = now()
   where id = target and role <> 'admin';
end;
$$;

-- A rejected user fixes their profile and asks for another review.
create or replace function resubmit_profile() returns void
language sql security definer set search_path = public as $$
  update profiles set status = 'pending', rejection_reason = null
  where id = auth.uid() and status = 'rejected';
$$;

-- Controlled booking status changes (who may move to which status).
create or replace function set_booking_status(b uuid, s text) returns void
language plpgsql security definer set search_path = public as $$
declare bk bookings;
begin
  select * into bk from bookings where id = b;
  if not found then raise exception 'Booking not found'; end if;

  if auth.uid() = bk.provider_id and (
       (bk.status = 'requested' and s in ('accepted','declined'))
    or (bk.status = 'accepted'  and s = 'completed')) then
    update bookings set status = s where id = b;
  elsif auth.uid() = bk.customer_id and bk.status in ('requested','accepted') and s = 'cancelled' then
    update bookings set status = s where id = b;
  else
    raise exception 'Not allowed';
  end if;
end;
$$;

-- ---------- 5. Security policies (Row Level Security) ------------------

alter table cities             enable row level security;
alter table categories         enable row level security;
alter table profiles           enable row level security;
alter table provider_documents enable row level security;
alter table services           enable row level security;
alter table bookings           enable row level security;
alter table reviews            enable row level security;

-- cities & categories: readable by everyone (needed on the sign-up form)
create policy "read cities"     on cities     for select to anon, authenticated using (true);
create policy "read categories" on categories for select to anon, authenticated using (true);
create policy "admin cities"     on cities     for all to authenticated using (is_admin()) with check (is_admin());
create policy "admin categories" on categories for all to authenticated using (is_admin()) with check (is_admin());

-- profiles
create policy "read own profile" on profiles for select to authenticated
  using (id = auth.uid());
create policy "admin reads all profiles" on profiles for select to authenticated
  using (is_admin());
create policy "approved users see approved providers" on profiles for select to authenticated
  using (role = 'provider' and status = 'approved' and is_approved());
create policy "see people you have bookings with" on profiles for select to authenticated
  using (exists (select 1 from bookings b
                 where (b.customer_id = profiles.id and b.provider_id = auth.uid())
                    or (b.provider_id = profiles.id and b.customer_id = auth.uid())));

-- Users may edit only these columns of their own row. role, status and
-- public_id can never be changed from the app.
revoke update on profiles from anon, authenticated;
grant  update (full_name, phone, city_id, category_id, bio, experience_years)
       on profiles to authenticated;
create policy "update own profile" on profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- provider documents
create policy "insert own documents" on provider_documents for insert to authenticated
  with check (provider_id = auth.uid());
create policy "read own or admin documents" on provider_documents for select to authenticated
  using (provider_id = auth.uid() or is_admin());

-- services
create policy "browse services" on services for select to authenticated
  using ((is_published and is_approved() and provider_is_approved(provider_id))
         or provider_id = auth.uid() or is_admin());
create policy "providers add services" on services for insert to authenticated
  with check (provider_id = auth.uid() and is_approved_provider());
create policy "providers edit own services" on services for update to authenticated
  using (provider_id = auth.uid() and is_approved_provider())
  with check (provider_id = auth.uid());
create policy "providers delete own services" on services for delete to authenticated
  using (provider_id = auth.uid());

-- bookings (no UPDATE policy on purpose: status changes go through set_booking_status)
create policy "see own bookings" on bookings for select to authenticated
  using (customer_id = auth.uid() or provider_id = auth.uid() or is_admin());
create policy "customers create bookings" on bookings for insert to authenticated
  with check (customer_id = auth.uid() and is_approved_customer());

-- reviews
create policy "approved users read reviews" on reviews for select to authenticated
  using (is_approved() or is_admin());
create policy "customers add reviews" on reviews for insert to authenticated
  with check (customer_id = auth.uid());

-- ---------- 6. Browse view (services + provider name + rating) ---------
-- security_invoker = the policies above still apply to whoever queries it.
create or replace view service_feed with (security_invoker = true) as
select s.id, s.title, s.description, s.price, s.price_type, s.is_published,
       s.category_id, c.name as category_name, s.city_id,
       s.provider_id, p.full_name as provider_name, p.public_id as provider_public_id,
       coalesce(r.avg_rating, 0)   as avg_rating,
       coalesce(r.review_count, 0) as review_count
from services s
join profiles   p on p.id = s.provider_id
join categories c on c.id = s.category_id
left join (select provider_id, avg(rating)::numeric(3,2) as avg_rating, count(*) as review_count
           from reviews group by provider_id) r on r.provider_id = s.provider_id;

grant select on service_feed to authenticated;

-- ---------- 7. Private storage for ID documents ----------------------
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do nothing;

-- Each user uploads into a folder named after their own user id.
create policy "upload own documents" on storage.objects for insert to authenticated
  with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "read own or admin documents" on storage.objects for select to authenticated
  using (bucket_id = 'documents'
         and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()));

-- ---------- 8. Starter data (edit freely) ------------------------------
insert into cities (name) values ('My City');
insert into categories (name) values
  ('Plumber'), ('Electrician'), ('Cleaner'), ('Tutor'), ('Mechanic'), ('Carpenter');
